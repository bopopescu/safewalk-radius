.. currentmodule:: kombu.abstract

.. automodule:: kombu.abstract

    .. contents::
        :local:

    .. autoclass:: MaybeChannelBound
        :members:
        :undoc-members:
