=========================================
 kombu.transport.django
=========================================

.. currentmodule:: kombu.transport.django

.. automodule:: kombu.transport.django

    .. contents::
        :local:

    Transport
    ---------

    .. autoclass:: Transport
        :members:
        :undoc-members:

    Channel
    -------

    .. autoclass:: Channel
        :members:
        :undoc-members:
