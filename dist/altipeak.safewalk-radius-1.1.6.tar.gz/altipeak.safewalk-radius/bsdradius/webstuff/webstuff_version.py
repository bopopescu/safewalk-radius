"""
Contains BSD Radius server version info
"""

# HeadURL		$HeadURL: file:///Z:/backup/svn/webstuff/tags/release20061229_v_1_0_0/webstuff/webstuff_version.py $
# Author:		$Author: valts $
# File version:	$Revision: 9 $
# Last changes:	$Date: 2006-03-31 19:26:39 +0300 (Pk, 31 Mar 2006) $


major = 0
minor = 1
debug = 0

fullVersion = '%s.%s.%s' % (major, minor, debug)
